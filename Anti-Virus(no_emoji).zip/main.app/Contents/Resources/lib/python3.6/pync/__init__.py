__version__ = "2.0.3"

from .TerminalNotifier import Notifier, notify
